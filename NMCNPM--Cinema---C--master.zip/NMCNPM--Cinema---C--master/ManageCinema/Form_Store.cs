﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageCinema
{
    public class Form_Store
    {
        public static HomePage homePage = new HomePage();
        public static MovieForm movieForm = new MovieForm();
    }
}
